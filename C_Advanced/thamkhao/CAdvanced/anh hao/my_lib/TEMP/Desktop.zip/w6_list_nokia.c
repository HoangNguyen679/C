#include<stdio.h>
#include<stdlib.h>
#define max 20
typedef struct _nokia
{
	char model[max];
	float storage;
	float screen;
	int price;
	
} nokia;
typedef nokia elementtype;
typedef struct _node //struct node
{
	elementtype data;
	struct _node *next;
	
} node;
typedef struct _list
{
	node *head;
} list;
list *beginlist() //khoi tao list
{
	list *l;
	l=(list *)malloc(sizeof(node));
	l->head=NULL;
	return 1;
}
//------------------------------tao node
int *makenode(elementtype d)
{
	node *t;
	t=(node*)malloc(sizeof(node));
	t->data=d;
	t->next=NULL;
} 
// ------------------------------add element to list
void makelist(list *l, elementtype d)
{
	node *n;
	n=makenode(d);
	n->next=l->head;
	l->head=n;
}
//--------------------------print data of list
void printfdata(elementtype d)
{
printf("%-7s %8.0f %6.1f %13d\n", d.model,d.storage,d.screen,d.price);
}
//--------------------------travese list
void tranverselist(list *l)
{
	node *n=l->head;
	while(n!=NULL){
		printfdata(n->data);
		n=n->next;
	}
}
//-------------------------- insert after one element of list
void insertafter(list *l, elementtype d, int vitri)
{
	node *n, *ptr;
	n=makenode(d);
	ptr=l->head;
	int i=1;
	// search position
	while(i<=vitri || ptr->next!=NULL){
		ptr=ptr->next;
		i++;
	}
	if(ptr==NULL) {printf("Khong ton tai vi tri can chen!\n"); return;}
	//insert element
	n->next=ptr->next;
	ptr->next=n;
}
// insert before
void insertbefore(list *l, elementtype d, int vitri)
{
	node *n,*p,*q;
	n=makenode(d);
	p=l->head;
	int i=1;
	while(p=!NULL && i<=vitri){
		p=p->next;
		if(i>=2) q=p;
		i++;
	}
	if(p==NULL) {printf("position not exist\n"); return;}
	else if(vitri==1) {makelist(l, d); return;}
	else if(q==NULL) {makelist(l, d); return;}
	else insertafter(l,d,(vitri-1));
}
//------------------------------------------------DELETE--
// delete fist
void deletefist(list *l)
{
	node *p;
	if(l->head==NULL) return;
	p=l->head;
	l->head=l->head->next;
	free(p);
	return;
}
void deletecurrent(list *l, int vitri)
{
	node *n=l->head;
	if(n==NULL) return;
	if(vitri==1) deletefist(l); return;
	int i=2;
	while(i<vitri && n->next!=NULL)
	{
		n=n->next;
		i++;
	}
	node *p=n->next;
	n->next = n->next->next;
	free(p);
	return;
}
//------------------------------------------------------
//------------------------search and update data of element
void search_and_update(list *l,char smodel[max])
{
	node *p=l->head;
	int z=0;
	while(p!=NULL){
		if(strcmp(p->data.model,smodel)==0){z=1; break;}
	 	p=p->next;
	}
	if(z==0){printf("Element doesn't exist\n"); return;}
	printf("would you want to update data of this model?\n");
	printf("1.yes\n2.no\n");
	int schoose;
	do{
	printf("your choose: ");
	scanf("%d",&schoose);
	} while(schoose!=1 && schoose!=2);
	if(schoose==2) return;
	else
	{
		printf("Enter size of storage: "); scanf("%f", &p->data.storage);
		printf("Enter size of screen: "); scanf("%f", &p->data.screen);
		printf("Enter the price: "); scanf("%d", &p->data.price);
	}
	return;
}
//-----------------------------------save to file
void save(list *l)
{
	node *n=l->head;
	FILE *f;
	f=fopen("filesave.dat","wb");
	while(n!=NULL){
		fwrite(&n->data,sizeof(nokia),1,f); //ghi vao file "filesave.dat"
	}
	return;
}
//---------------------------enter data of element
elementtype makedata()
{
	elementtype d;
	printf("Enter model: "); scanf("%s",&d.model);
	printf("Enter storage: "); scanf("%f", &d.storage);
	printf("Enter size of screen: "); scanf("%f",&d.screen);
	printf("Enter the price: "); scanf("%d", &d.price);
	return d;
}
int menu()
{
	int choose;
	do{
	printf("MENU\n");
	printf("1.Inport from DAT\n");
	printf("2.Dislay\n");
	printf("3.Add new phone\n");
	printf("4.Delete fist\n");
	printf("5.Deletecurvrent\n");
	printf("6.search and update\n");
	printf("7.Save to file\n");
	printf("0.Exit\n");
	printf("your choose: "); scanf("%d",&choose);
	} while (choose<0 || choose>7 );
	return choose;
}
int main()
{
	int menuchoose;
	list *l;
	l=(list *)malloc(sizeof(node));
	l->head=NULL;
	
	do{
		menuchoose = menu();
	switch(menuchoose)
	{
		case 1:{
			FILE *file;
			file = fopen("nokia.dat","rb");
			if(file==NULL) {perror("Can't open data file\n"); break;}
			else{
			nokia xxdata;
			while(fread(&xxdata,sizeof(elementtype),1, file)>=1){
				makelist(l,xxdata);
			}
			}
			deletefist(l);
			break;
			}
		case 2:
			tranverselist(l); break;
		case 3:{
			int vitri, cc;
			printf("Vi tri muon them: "); scanf("%d", &vitri);
			do{
			printf("Option:\n1.insert After\n2.Insert Before\n");
			printf("Your choose: "); scanf("%d",&cc);
			} while(cc!=1 && cc!=2);
		
			if(cc==1){
				insertafter(l,makedata(),vitri);
			}
			else insertbefore(l,makedata(),vitri); //chua thanh cong(can chinh sua)
		
			break;
			}
		case 4: deletefist(l); break;
		case 5:{ 								//chua thanh cong(can chinh sua)
			int vitrixoa;
			printf("Vi tri muon xoa: "); scanf("%d", &vitrixoa);
			deletecurrent(l,vitrixoa);
			break;
			}
		case 6:{
				char smodel[max];
				printf("Enter the model: "); scanf("%s",smodel);
				search_and_update(l,smodel);
			break;
			}
		case 7:{
			save(l);
			break;
		}
		
	}
	} while(menuchoose!=0);
}
