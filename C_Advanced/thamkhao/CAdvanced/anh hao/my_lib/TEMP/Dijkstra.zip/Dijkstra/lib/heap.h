/****************************** Module Header ******************************\
* Module Name:  heap.h
* Project:      Dijkstra
* Copyright (c) Nguyen Van Hao - Nghiem Nguyen Viet Dung - ICT-K56
* 
* Provice methods of heap data structure.
* 
* This source is subject to Data Structure and Algorithm Exercise.
* All other rights reserved.
* 
* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
* EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
\***************************************************************************/
typedef  struct typeHeap_t{
	int info[MAX];
	int size; 
}typeHeap;

void InitHeap(typeHeap *heap){
	heap->size = 0;
}

int PopHeap(typeHeap *heap){
	if (heap->size == 0) return 0;
	int ans = heap->info[1];
	pos[ans] = 0;
	int minChild;
	int father = 1;
	int lastNode = heap->info[heap->size];
	double key = dis[lastNode];
	heap->size--;
	if (heap->size == 0) return ans;
	while (father << 1 <= heap->size){
		minChild = father << 1;
		if (minChild < heap->size)
			if (dis[heap->info[minChild+1]] < dis[heap->info[minChild]])
				minChild++;
		if (dis[heap->info[minChild]] > key) break;
		pos[heap->info[minChild]] = father;
		heap->info[father] = heap->info[minChild];
		father = minChild;	
	}
	pos[lastNode] = father;
	heap->info[father] = lastNode;
	return ans;
}

void PushHeap(typeHeap *heap, int vertex){
	if (pos[vertex] == 0) pos[vertex] = ++heap->size;
	int child = pos[vertex], father;
	double key = dis[vertex];
	while (child != 1){
		father = child >> 1;
		if (dis[heap->info[father]] < key) break;
		pos[heap->info[father]] = child;
		heap->info[child] = heap->info[father];
		child = father;
	}
	heap->info[child] = vertex;
	pos[vertex] = child;
}
