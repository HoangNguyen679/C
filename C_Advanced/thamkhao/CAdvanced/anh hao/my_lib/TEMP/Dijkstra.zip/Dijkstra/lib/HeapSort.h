/****************************** Module Header ******************************\
* Module Name:  HeapSort.h
* Project:      Dijkstra
* Copyright (c) Nguyen Van Hao - Nghiem Nguyen Viet Dung - ICT-K56
* 
* Provice method to sorting data. 
* 
* This source is subject to Data Structure and Algorithm Exercise.
* All other rights reserved.
* 
* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
* EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
\***************************************************************************/

void Exchange(t_point *a, t_point *b);
void MaxHeapify(t_point *A, int i, int n);
void BuildMaxHeap(t_point *A, int n);
void HeapSort(t_point *A, int n);



/****************FUNCTIONS*****************/
void Exchange(t_point *a, t_point *b){
	t_point temp = *a;
	*a = *b;
	*b = temp;
}

void MaxHeapify(t_point *A, int i, int n){
	int l = 2*i;
	int r = 2*i+1;
	int largest;

	if (l<=n && ComparePoint(A[l],A[i])==1) largest = l;
	else largest = i;

	if (r<=n && ComparePoint(A[r],A[largest])==1) largest = r;

	if (largest != i){
		Exchange(A+i, A+largest);
		MaxHeapify(A, largest, n);
	}
}

void BuildMaxHeap(t_point *A, int n){
	int i;
	for(i=n/2; i>=1; i--) MaxHeapify(A, i, n);
}


void HeapSort(t_point *A, int n){
	BuildMaxHeap(A, n);
	int i;
	for(i=n; i>=2; i--) {
		Exchange(A+1, A+i);
		MaxHeapify(A, 1, i-1);
	}
}