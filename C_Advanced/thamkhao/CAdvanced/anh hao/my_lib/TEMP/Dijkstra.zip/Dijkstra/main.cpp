/****************************** Module Header ******************************\
* Module Name:  main.cpp
* Project:      Dijkstra
* Copyright (c) ICT-K56
* 
* The main of application. Provice all methods to find a shortest path
* from two points of a map using Dijkstra Algorithm
* 
* This source is subject to Data Structure and Algorithm Exercise.
* All other rights reserved.
* 
* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
* EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
\***************************************************************************/

#include <iostream>
#include <stdio.h>
//#include <conio.h>
#include <stdlib.h>
#include "lib//Timer.cpp"
#define MAXWEIGHT 100000
#define MAX 60000
#define EPSILON 1E-7

#define FILENAME "hcm-cc-contracted.mp"					// Source map
#define OUTPUTFILE "ShortestPath.mp"					// Output map (include shortest path)

/* Member Struce Declaration */
typedef struct point_t{
	double latitude;
	double longitude;
} t_point;												// point (vertex)

typedef struct elementType_t{
	int vertex;
	double weight;
} elementType;											// Edge 

/* Member Function Declaration*/
void Dijkstra(int start, int end);
void PrintData(elementType e);
int ComparePoint(t_point a, t_point b);
int BinarySearch(int Lo, int Hi, t_point key);
void Input();
void Output(const char *fileIn, const char *fileOut);

t_point Point[MAX];										// Array of all vertex in ma
double dis[MAX];
int pos[MAX], ans[MAX];
int numPoint, numEdge;									// numPoint = number of vertex, numEdge = number of Edge

#include "lib//SLLLib.h"
SLList Edge[MAX];										// Array of Link List 
#include "lib//input.cpp"
#include "lib//HeapSort.h"
#include "lib/heap.h"


int main(int argc, char const *argv[]) {

	/*Start Read from source map*/
	cout <<	"\nStart Reading map \"" << FILENAME << "\""<< endl;
	Timer *r_timer = new Timer(); 						//Start Reading Timer
	Input();
	cout << "Reading time: " << r_timer->getElapsedTime()*1000 << "ms" << endl; 	
	/*End read from source map*/


	/*Get Start and End Point*/
	t_point start, end;
	cout << "\nInput. Example : (10.12345,106.12345)" << endl;
	cout << "Start Point: "; fflush(stdin); scanf("(%lf,%lf)", &start.latitude, &start.longitude);
	cout << "End Point  : "; fflush(stdin); scanf("(%lf,%lf)", &end.latitude  , &end.longitude  );

	// Start point and end point (cua thay Dung)
	// start.latitude = 10.738932;
	// start.longitude = 106.623631;
	// end.latitude = 10.816849;
	// end.longitude = 106.720139;

	int vertex_start = BinarySearch(1,numPoint,start), vertex_end = BinarySearch(1,numPoint,end);
	if(vertex_start == -1 || vertex_end == -1) { 		// Cannot search Start or End Point
		cout << "Cannot locate Start or End Point!" << endl;
		//getch();
		exit(1);
	}
	/*End Get*/

	/* Start Dijkstra Algorithm*/
	cout << "\nProcessing Dijkstra" << endl;
	Timer *m_timer = new Timer(); 						//Start Dijkstra Timer
	Dijkstra(vertex_start, vertex_end);
	cout << "Timer Elapsed: " << m_timer->getElapsedTime()*1000 << "ms" << endl; 	//End Dijkstra Timer
	cout << "Done! Open output map to see result\n" << endl;						
	/* End Dijkstra*/

	Output(FILENAME, OUTPUTFILE);						// Write to output file	
	//for (int i = 1;i <= ans[0];i++) cout << ans[i] << "  "; 			// Show shortest path by Point to Point
														
	for (int i = 1; i <= numPoint; i++) FreeAllList(&Edge[i]);			// Free memory (link list)
	//getch();
	return 0;
}

/* Member Function */
void PrintData(elementType e){
	printf("%d-", e.vertex);
}

int ComparePoint(t_point a, t_point b){
	if ( fabs(a.latitude-b.latitude) < EPSILON ) {
		if ( fabs(a.longitude-b.longitude) < EPSILON) return 0;
		if ( a.longitude < b.longitude) return -1;
		return 1;
	}
	if (a.latitude < b.latitude) return -1;
	return 1;
}

int BinarySearch(int Lo, int Hi, t_point key){
	if (Lo > Hi) return -1;
	int Mid = (Lo+Hi) / 2;
	if (ComparePoint(Point[Mid], key) == -1) return BinarySearch(Mid+1, Hi, key);
	if (ComparePoint(Point[Mid], key) == 1) return BinarySearch(Lo, Mid-1, key);
	return Mid;
}

void Dijkstra(int start, int end){
	typeHeap heap;
	InitHeap(&heap);
	int curPoint = start;
	int i, prePoint[MAX];
	for (i=1; i<=numPoint; i++){
		dis[i] = MAXWEIGHT;
		pos[i] = 0;
	}
	dis[start] = 0.0;
	prePoint[start] = 0;
	PushHeap(&heap,start);
	while (1){
		int u = PopHeap(&heap);
		if (u == end) break;
		node *t = Edge[u].root;
		int v;
		double w;
		while (t != NULL){
			v = t->element.vertex;
			w = t->element.weight;
			if (dis[u] + w < dis[v]){
				prePoint[v] = u;
				dis[v] = dis[u] + w;
				PushHeap(&heap,v);
			}
			t = t->next;
		}
	}
	ans[0] = 0;
	while (prePoint[end] != 0){
		ans[0]++;
		ans[ans[0]] = end;
		end = prePoint[end];
	}
	ans[0]++;
	ans[ans[0]] = end;
}

void Output(const char *fileIn, const char *fileOut){
	FILE *fin, *fout;
	if ((fin = fopen(fileIn, "r")) == NULL) { perror("ERROR"); exit(1); }
	if ((fout = fopen(fileOut, "w")) == NULL) { perror("ERROR"); exit(1); }
	
		//copy all source map to output map
	char buffer[MAX];
	while(!feof(fin)){
		int frc = fread(buffer, 1, MAX-1, fin);
		if (frc == 0) break;
		fwrite(buffer, 	1, frc, fout);
	}

		//appending shortest path to output
	for(int j=0; j<5; j++){
		fprintf(fout, "\n[POLYLINE]\nType=0x01\nLabel=Shortest Path\nData%d=", j);
		for(int i = 1; i <= ans[0]; i++)
			fprintf(fout, "(%lf,%lf),", Point[ans[i]].latitude, Point[ans[i]].longitude);
		fprintf(fout, "\n[END]\n");
	}

	fclose(fin);
	fclose(fout);
}

void Input(){
	CInput *m_input = new CInput();
	HeapSort(Point, m_input->ReadPoint(FILENAME)); 		// Read source map and make a array of point and sort them (this take O(n))
	numPoint = m_input->DeleteEqualPoint();				// Delete all same point
	//m_input->ShowPoint(); 							// Show all point
	numEdge = m_input->ReadEdge(FILENAME);						// Read source map again and make a array of list, 
														//  each list contain adjcient points and its weight
	//for (int i = 1; i <= numPoint; i++){TraverseList(&Edge[i]); cout << endl; } //Show All Edge								
	cout << "Number of Vertices: " << numPoint << endl;
	cout << "Number of Edges    : " << numEdge  << endl;
}