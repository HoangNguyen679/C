/****************************** Module Header ******************************\
* Module Name:  Input.h
* Project:      Dijkstra
* Copyright (c) ICT-K56
* 
* Provice input method of the application. 
* 
* This source is subject to Data Structure and Algorithm Exercise.
* All other rights reserved.
* 
* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
* EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
\***************************************************************************/

using namespace std;

class CInput {
public:
	CInput();
	~CInput();

	int ReadPoint(const char *finename);
	int DeleteEqualPoint();
	//int ComparePoint(t_point a, t_point b);
	void ShowPoint();
	int ReadEdge(const char *filename);
	void AddEdge(int pre, int next);


private:
	int numPoint;
	int Data0count;

};