/****************************** Module Header ******************************\
* Module Name:  Input.cpp
* Project:      Dijkstra
* Copyright (c) Nguyen Van Hao - Nghiem Nguyen Viet Dung - ICT-K56
* 
* Provice input method of the application. 
* 
* This source is subject to Data Structure and Algorithm Exercise.
* All other rights reserved.
* 
* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
* EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
\***************************************************************************/
#include "input.h"
//#include <iostream>
#include <string.h>
#include <math.h>

using namespace std;

CInput::CInput(){
	numPoint = 0;
	Data0count = 0;
}

CInput::~CInput(){
}

int CInput::ReadPoint(const char *filename){
	FILE *f = fopen(filename, "r");
	if (f == NULL){
		perror("ERROR");
		exit(1);
	}

	char s[100];
	int i = 1;

	while (!feof(f)){
		fgets(s, 7, f);
		if(!strcmp(s,"Data0=")){
			Data0count++;
			while(1){
				if (fscanf(f, "(%lf,%lf),", &Point[i].latitude, &Point[i].longitude) == 0) break;
				i++;
			}
		}
	}
	numPoint = i;
	fclose(f);
	return numPoint;
}

int CInput::DeleteEqualPoint(void){
	int j = 0;
	for (int i = 1; i <= numPoint; i++){
		if(ComparePoint(Point[i], Point[j]) != 0){
			j++;
			Point[j] = Point[i];
		}
	}
	numPoint = j;
	return numPoint;
}

void CInput::ShowPoint(){
	for (int i = 1; i <= numPoint; i++)
		printf("(%lf,%lf),\n", Point[i].latitude, Point[i].longitude);
	printf("Total Data0 Found: %d\n", Data0count);
	printf("Total Point: %d\n", numPoint);
}

int CInput::ReadEdge(const char *filename){
	FILE *f = fopen(filename, "r");
	if (f == NULL){
		perror("ERROR");
		exit(1);
	}

	char s[100];
	int i = 1;
	int numEdge = 0;

	t_point temp;
	t_point temp1;

	while (!feof(f)){
		fgets(s, 7, f);
		if(!strcmp(s,"Data0=")){

			int pre, next;
			fscanf(f, "(%lf,%lf),", &temp.latitude, &temp.longitude) == 0;
			pre = BinarySearch(0, numPoint, temp);

			while(1){
				if (fscanf(f, "(%lf,%lf),", &temp.latitude, &temp.longitude) == 0) break;
				next= BinarySearch(0, numPoint, temp);
				AddEdge(pre, next); 
				pre = next;			
				numEdge++;	
			}
		}
	}
	fclose(f);
	return numEdge;
}

void CInput::AddEdge(int pre, int next){
	elementType temp;
	temp.vertex = next;
	temp.weight = sqrt( pow((Point[pre].latitude-Point[next].latitude),2) + pow((Point[pre].longitude-Point[next].longitude),2) );
	InsertAfterCurrent(&Edge[pre], temp);

	temp.vertex = pre;
	InsertAfterCurrent(&Edge[next], temp);
}