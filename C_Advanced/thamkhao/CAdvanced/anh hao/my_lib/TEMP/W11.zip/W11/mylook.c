#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>


#define WORD "word-linux"
#define MAX 20

typedef struct MyWord_t{
	char myword[MAX];
} elementType;

void PrintData(elementType e);

#include "SLLLib.h"


int main(int argc, char **argv){
	if (argc != 2) {
		printf("Invailid Argument! (e.g: ./mylook wordtosearch)\n");
		exit(1);
	}

	FILE *fileIn = fopen(WORD, "r");
	if (fileIn == NULL) {
		perror("ERROR");
		exit(1);
	}

	
	while (feof(fileIn) == 0){
		elementType temp;
		if (fgets(temp.myword, MAX, fileIn) == NULL) break;
		(temp.myword)[strlen(temp.myword)-1] = '\0';
		InsertAfterCurrent(temp);
	}

	int isFound = 0;
	node *p = root;
	for(p=root; p!=NULL; p=p->next){
		if(strstr(p->element.myword,argv[1])) {
			int i, isOK=1;
			for(i=0; i<strlen(argv[1]); i++){
				if(p->element.myword[i] != (argv[1])[i]) isOK=0;
			}
			if(isOK){
				PrintData(p->element);
				isFound = 1;
			}
		}
	}
	if(isFound == 0) printf("Could not found!");
	FreeAllList();
	fclose(fileIn);
	return 0;
}

void PrintData(elementType e){
	printf("%s\n", e.myword);
}