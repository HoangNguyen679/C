#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 81
typedef struct add
{char name[MAX],mssv[40];float diem;}add;
typedef struct node
{add data;struct node *next;}node;
int TAIL=0;
void menu(char* ar)
{
  printf("Menu:\n");
  printf("1-Import data from data.dat file\n");
  printf("2-Insert data into list\n");
  printf("3-Delete data from list\n");
  printf("4-Change data in list\n");
  printf("5-Find a data\n");
  printf("6-Reserve list\n");
  printf("7-Show list\n");
  printf("8-Update the change in file %s\n",ar);
  printf("9-Show file\n");
  printf("10-Exit\n");
  printf("+++*Chon 0 de tro lai menu chinh*+++\n");
}
void conv_dat(FILE *f1,FILE *f2)
{
  char buff[MAX],x1[MAX],x2[MAX],x3[MAX];
  add *data;
  rewind(f1);
  while(!feof(f1))
    {fscanf(f1,"%s%s%s",x1,x2,x3);
      data=(add *)malloc(sizeof(add));
      strcpy(data->name,x1);strcpy(data->email,x2);strcpy(data->dt,x3);
      if(!feof(f1))
        fwrite(data,sizeof(add),1,f2);
      free(data);}
}
void inp(add *data)
{
  add tmp;
  char buff[MAX];
  while(getchar()!='\n');
  printf("Ten:");scanf("%s",tmp.name);
  do{printf("MSSV:");scanf("%s",buff);}while(!check_data(buff));
  strcpy(tmp.dt,buff);
  printf("Diem:");scanf("%f",tmp.diem);
  *data=tmp;
}
node *search(node *root,int n)
{
  node *tmp;
  int i=0;
  for(tmp=root;tmp!=NULL;tmp=tmp->next) {i++;if(i==n) break;}
  return tmp;
}
node *insert_s(node *root,add data)
{
  node *new,*cur;
  new=(node*)malloc(sizeof(node));
  new->data=data;
  if(root==NULL)
    {new->next=NULL;new->pre=NULL;root=new;}
  else
    {for(cur=root;cur->next!=NULL;cur=cur->next)
        if(cur->data.gia>data.gia) break;
      if(cur==root)
        {new->next=root;new->pre=NULL;root=new;}
      else
        if(cur->next==NULL)
          if(cur->data.gia>data.gia)
            {new->next=cur;new->pre=cur->pre;cur->pre->next=new;cur->pre=new;}
          else{new->pre=cur;new->next=NULL;cur->next=new;}
        else
          {new->next=cur;new->pre=cur->pre;cur->pre->next=new;cur->pre=new;}
    }
  TAIL++;
  return root;
}
node *creat(node *root,FILE *f)
{
  node *new,*cur=NULL;
  add *data;
  rewind(f);
  root=NULL;
  TAIL=0;
  data=(add *)malloc(sizeof(add));
  while(!feof(f))
    {
      fread(data,sizeof(add),1,f);
      if(!feof(f))
        root=insert(root,*data,TAIL);
    }
  return(root);
}
node *del(node *root,int n)
{
  node *tmp=NULL,*cur=NULL;
  if(n<1||n>TAIL) {printf("Cant find data\n");return root;}
  if(n==1) {root=root->next;return(root);}
  else
    {cur=search(root,n-1); tmp=cur->next;cur->next=tmp->next;free(tmp);}
  TAIL--;
  return root;
}
void show(node *root)
{
  int n=0;
  node *cur=NULL;
  printf("%-5s%-40s%-15s%-10s\n"."STT","Ten","MSSV","Diem");
  for(cur=root;cur!=NULL;cur=cur->next)
    printf("%-5d%-40s%-15s%-10g\n",++n,cur->data.name,cur->data.mssv,cur->data.diem);
  free(cur);
}
void free_n(node *root)
{
  node *to_free;
  to_free=(node*)malloc(sizeof(node));
  to_free=root;
  while(to_free!=NULL)
    {root=root->next;free(to_free);to_free=root;}
}
void show2(FILE *f)
{
  add *data;
  rewind(f);
  data=(add*)malloc(sizeof(add));
  printf("%-40s%-15s%-10s\n"."STT","Ten","MSSV","Diem");
  while(!feof(f))
    {
      fread(data,sizeof(add),1,f);
      if(!feof(f))
        printf("%-40s%-15s%-10g\n",++n,data->name,data->mssv,data->diem);
    }
  free(data);
}
node *change(node *root,int n)
{
  node *cur;
  add data;
  if(n>0&&n<=TAIL)
    {cur=search(root,n);
      printf("Nhap du lieu moi:");
      inp(&data);
      cur->data=data;
    }
  else
    printf("Cant find data\n");
  return root;
}
void *update(node *root,FILE *f)
{
  node *tmp;
  add data;
  tmp=(node *)malloc(sizeof(node));
  for(tmp=root;tmp!=NULL;tmp=tmp->next)
    {
      data=tmp->data;
      fwrite(&data,sizeof(add),1,f);
    }
  free(tmp);
}
int check_data(char dt[])
{
  char buff[MAX];
  int i;
  strcpy(buff,dt);
  for(i=0;buff[i]!='\0';i++)
    if ('0'>buff[i]||buff[i]>'9') return 0;
  return 1;
}

node *re(node *root)
{
  node *old,*cur,*tmp;
  tmp=root->next;
  root->next=NULL;
  while(tmp!=NULL)
    {
      cur=(node *)malloc(sizeof(node));
      cur->data=tmp->data;
      cur->next=root;
      root=cur;
      old=tmp;
      tmp=tmp->next;
      free(old);
    }
  return root;
}
void find1(node *root,char buff[])
{
  node *cur=NULL;
  int n=0;
  printf("%-5s%-40s%-15s%-10s\n"."STT","Ten","MSSV","Diem");
  for(cur=root;cur!=NULL;cur=cur->next)
    if(strcmp(buff,cur->data.name)==0)
      printf("%-5d%-40s%-15s%-10g\n",++n,data->name,data->mssv,data->diem);
  if(n==0) printf("Cant file data\n");
}
void find2(node *root,char buff[])
{
  node *cur=NULL;
  int n=0;
  printf("%-5s%-40s%-15s%-10s\n"."STT","Ten","MSSV","Diem");
  for(cur=root;cur!=NULL;cur=cur->next)
    if(strcmp(buff,cur->data.dt)==0)
      printf("%-5d%-40s%-15s%-10g\n",++n,data->name,data->mssv,data->diem);
  if(n=0) printf("Cant file data\n");
}
