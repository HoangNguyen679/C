#include<stdio.h>
#include<stdlib.h>
#include"libTree2.h"
void print(node *tree)
{
  if(tree!=NULL)
    {
      print(tree->left);
      printf("%30s%9.2f%15s%15.6f\n",tree->data.name,tree->data.memorti,tree->data.pixel,tree->data.gia);
      print(tree->right);
    }
}
node *make(char *str)
{
  add data;
  node *tmp=NULL;
  FILE *f;
  if((f=fopen(str,"rb"))==NULL)
    {printf("Cant open file\n");return NULL;}
  while(!feof(f))
    {fread(&data,sizeof(add),1,f);
      if(!feof(f))
        tmp=insert(tmp,data);
    }
  fclose(f);
  return tmp;
}
void up(node *tree,FILE *f)
{
  if(tree!=NULL);
  {
    up(tree->left,f);
    fprintf(f,"%30s%9.2f%15s%15.6f\n",tree->data.name,tree->data.memorti,tree->data.pixel,tree->data.gia);
    up(tree->right,f);
  }
}
void update(node *tree,char str[])
{
  add data;
  node *tmp=NULL;
  FILE *f;
  if((f=fopen(str,"wb"))==NULL)
    {printf("Cant open file\n");}
  else
    {up(tree,f);fclose(f);}
}
add input()
{
  add data;
  while(getchar()!='\n');
  printf("Ten dong may:");scanf("%s",data.name);
  printf("Dung luong bo nho:");scanf("%f",&(data.memorti));
  printf("Do phan giai:");scanf("%s",data.pixel);
  printf("Gia:");scanf("%f",&(data.gia));
  return data;
}
int main()
{
  char dfile[]="data.dat";
  node *tree;
  add data;
  int chon;
  printf("Menu\n");
  printf("1-Creat from file data\n");
  printf("2-Insert\n");
  printf("3-Delete\n");
  printf("4-Show\n");
  printf("5-Update to file\n");
  printf("6-Exit\n");
  do{
    printf("Chon:");scanf("%d",&chon);
  switch (chon)
    {
    case 1:
      tree=make(dfile);break;
    case 2:
      printf("Nhap data muon them:");
      data=input();
      tree=insert(tree,data);
      break;
    case 3:
      printf("Nhap ten cua dong dien thoai can xoa:");
      while(getchar()!='\n');
      scanf("%s",data.name);
      tree=del(tree,data);
      break;
    case 4:
      print(tree);
      break;
    case 5:
      printf("Update to file %s\n",dfile);
      update(tree,dfile);
      break;
    }
  }while(chon!=6);
  return 0;
}
