#include<stdio.h>
#include<stdlib.h>
typedef int add;
typedef struct node
{add data;struct node *next;}node;
node *push(node *root,add data)
{
  node *new;
  new=(node*)malloc(sizeof(node));
  if(new==NULL)
    {printf("Stack is Full\n");return(root);}
  new->data=data;
  new->next=root;
  root=new;
  return root;
}
node *pop(node *root,add *data)
{
  node *tmp;
  if(root==NULL) {printf("Stack is empty\n");return root;}
  tmp=root;root=root->next;*data=tmp->data;free(tmp);return root;
}
