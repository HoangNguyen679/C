#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"stack_lib3.h"
#define MAX 80
void in(node *top)
{
  add d1;
  while(top!=NULL)
    {top=pop(top,&d1);printf("%d",d1);}
  printf("\n");
}
void sum(char s1[],char s2[])
{
  add d1,d2,r=0;
  int i;
  node *top1,*top2,*top;
  top1=top2=top=NULL;
  for(i=0;s1[i]!='\0';i++) top1=push(top1,s1[i]-'0');
  for(i=0;s2[i]!='\0';i++) top2=push(top2,s2[i]-'0');
  while(top1!=NULL&&top2!=NULL)
    {top1=pop(top1,&d1);top2=pop(top2,&d2);
      r=r+d1+d2;
      top=push(top,r%10);r=r/10;
    }
  while(top1!=NULL)
    {top1=pop(top1,&d1);r=r+d1;
      top=push(top,r%10);r=r/10;}
  while(top2!=NULL)
    {top2=pop(top2,&d1);r=r+d1;
      top=push(top,r%10);r=r/10;}
  if(r!=0) top=push(top,r);
  in(top);
}
void minus(char s1[],char s2[])
{
  add d1,d2,r=0;
  int i;
  node *top1,*top2,*top;
  top1=top2=top=NULL;
  if(strlen(s2)<strlen(s1)||(strlen(s1)==strlen(s2)&&strcmp(s1,s2)==1))
    {
      for(i=0;s1[i]!='\0';i++) top1=push(top1,s1[i]-'0');
      for(i=0;s2[i]!='\0';i++) top2=push(top2,s2[i]-'0');
      while(top1!=NULL&&top2!=NULL)
        {top1=pop(top1,&d1);top2=pop(top2,&d2);
          r=d1-d2-r;
          top=push(top,(10+r)%10);r=(9-r)/10;
        }
      while(top1!=NULL)
        {top1=pop(top1,&d1);
          r=d1-r;
          top=push(top,(10+r)%10);r=(9-r)/10;
        }
      while(top->data==0) top=pop(top,&d1);
      in(top);
    }
  else
    {printf("-");minus(s2,s1);}
}
int check(char str[])
{
  int i;
  for(i=0;str[i]!='\0';i++)
    if(str[i]<'0'||str[i]>'9') return 1;
  return 0;
}
int main()
{
  char s1[MAX],s2[MAX];
  int i,ch;
  do{printf("Nhap so nguyen duong thu nhat:");scanf("%s",s1);}while(check(s1));
  do{printf("Nhap so nguyen duong thu hai:");scanf("%s",s2);}while(check(s2));
  printf("1-Thuc hien cong 2 so\n");
  printf("2-Thuc hien so thu nhat tru so thu 2\n");
  printf("Chon:");
  scanf("%d",&ch);
  switch(ch)
    {
    case 1:sum(s1,s2);break;
    case 2:minus(s1,s2);break;
    }
  return 1;
}
