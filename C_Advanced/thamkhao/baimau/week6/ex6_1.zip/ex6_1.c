#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"lib.h"
int main(int argc,char* argv[])
{
  node *root=NULL,*cur=NULL;
  add data;
  FILE *f2;
  char buff[MAX];
  int chon,i,n,dem;
  if(argc!=2)
    {printf("Sai cu phap:%s <file data .dat>\n",argv[0]);exit(1);}
  else
    {
      menu(argv[1]);
      do{
        printf("Chon:");scanf("%d",&chon);
        switch(chon)
          {
          case 1:
            if((f2=fopen(argv[1],"r+b"))==NULL)
              {printf("Cant open file %s\n",argv[1]);exit(1);}
            else
              {root=creat(root,f2);fclose(f2);}
            break;
          case 2:
            printf("Nhap vi tri va du lieu ban muon chen:");
            printf("Vi tri:n=");
            scanf("%d",&n);
            inp(&data);root=insert(root,data,n);
            break;
          case 3:
            if(root==NULL) {printf("Nothing to delete!!!\n");break;}
            printf("Nhap vi tri ban muon del:");
            scanf("%d",&n);
            root=del(root,n);
            break;
          case 4:
            if(root==NULL) {printf("Nothing to change\n");break;}
            printf("Nhap vi tri du lieu ban muon thay doi:");
            scanf("%d",&n);
            printf("\n");
            root=change(root,n);
            break;
          case 5:
            do
              {
                printf("Tuy chon tim kiem:\n1-Theo ten\n2-Theo so DT\n3-Back\nChon:");
                scanf("%d",&n);
              }while(n<=0||n>=4);
            switch(n)
              {
              case 1:
                printf("Ten nguoi ban muon tim:");
                while(getchar()!='\n');
                scanf("%[^'\n']",buff);
                find1(root,buff);
                break;
              case 2:
                do
                  {printf("Nhap so dien thoai:");
                  while(getchar()!='\n');
                  scanf("%[^'\n']",buff);
                  }while(!check_data(buff));
                find2(root,buff);
                break;
              case 3:break;
              }
            break;
          case 6:
            if(root==NULL) {printf("Nothing to change\n");break;}
            root=re(root);
            break;
          case 7:
            show(root);
            break;
          case 8:
             if((f2=fopen(argv[1],"w+b"))==NULL)
              {printf("Cant open file %s\n",argv[1]);exit(1);}
             else
               {update(root,f2);fclose(f2);}
             break;
          case 9:
            if((f2=fopen(argv[1],"r+b"))==NULL)
              {printf("Cant open file %s\n",argv[1]);exit(1);}
            else
              {show2(f2);fclose(f2);}
            break;
          case 10:
            free_n(root);
            break;
          case 0:
            menu(argv[1]);
            break;
          }
      }while(chon!=10);
    }
}
