#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 81
typedef struct add
{char name[MAX],email[40],dt[15];}add;
typedef struct node
{add data;struct node *next;}node;
int TAIL=0;
void menu(char* ar)
{
  printf("Menu:\n");
  printf("1-Import data from data.dat file\n");
  printf("2-Insert data into list\n");
  printf("3-Delete data from list\n");
  printf("4-Change data in list\n");
  printf("5-Find a data\n");
  printf("6-Reserve list\n");
  printf("7-Show list\n");
  printf("8-Update the change in file %s\n",ar);
  printf("9-Show file\n");
  printf("10-Exit\n");
  printf("+++*Chon 0 de tro lai menu chinh*+++\n");
}
void conv_dat(FILE *f1,FILE *f2)
{
  char buff[MAX],x1[MAX],x2[MAX],x3[MAX];
  add *data;
  rewind(f1);
  while(!feof(f1))
    {fscanf(f1,"%s%s%s",x1,x2,x3);
      data=(add *)malloc(sizeof(add));
      strcpy(data->name,x1);strcpy(data->email,x2);strcpy(data->dt,x3);
      if(!feof(f1))
        fwrite(data,sizeof(add),1,f2);
      free(data);}
}
void inp(add *data)
{
  add tmp;
  char buff[MAX];
  while(getchar()!='\n');
  printf("Ten:");scanf("%s",tmp.name);
  printf("Email:");scanf("%s",tmp.email);
  do{printf("Dien thoai:");scanf("%s",buff);}while(!check_data(buff));
  strcpy(tmp.dt,buff);
  *data=tmp;
}
node *search(node *root,int n)
{
  node *tmp;
  int i=0;
  for(tmp=root;tmp!=NULL;tmp=tmp->next) {i++;if(i==n) break;}
  return tmp;
}
node *insert(node *root,add data,int n)
{
  node *new,*cur=NULL;
  new=(node *)malloc(sizeof(node));
  new->data=data;
  if(n==0) {new->next=root;root=new;}
  else
    {
      if(n>TAIL) cur=search(root,TAIL);
      else cur=search(root,n);
      {new->next=cur->next;cur->next=new;}
    }
  TAIL++;
  return(root);
}
node *creat(node *root,FILE *f)
{
  node *new,*cur=NULL;
  add *data;
  rewind(f);
  root=NULL;
  TAIL=0;
  data=(add *)malloc(sizeof(add));
  while(!feof(f))
    {
      fread(data,sizeof(add),1,f);
      if(!feof(f))
        root=insert(root,*data,TAIL);
    }
  return(root);
}
node *del(node *root,int n)
{
  node *tmp=NULL,*cur=NULL;
  if(n<1||n>TAIL) {printf("Cant find data\n");return root;}
  if(n==1) {root=root->next;return(root);}
  else
    {cur=search(root,n-1); tmp=cur->next;cur->next=tmp->next;free(tmp);}
  TAIL--;
  return root;
}
void show(node *root)
{
  int n=0;
  node *cur=NULL;
  for(cur=root;cur!=NULL;cur=cur->next)
    printf("\n%d-Ten:%-40sEmail:%s\nDien thoai:%s\n",++n,cur->data.name,cur->data.email,cur->data.dt);
  free(cur);
}
void free_n(node *root)
{
  node *to_free;
  to_free=(node*)malloc(sizeof(node));
  to_free=root;
  while(to_free!=NULL)
    {root=root->next;free(to_free);to_free=root;}
}
void show2(FILE *f)
{
  add *data;
  rewind(f);
  data=(add*)malloc(sizeof(add));
  while(!feof(f))
    {
      fread(data,sizeof(add),1,f);
      if(!feof(f))
        printf("\nName:%-40sEmail:%s\nDT:%s\n",data->name,data->email,data->dt);
    }
  free(data);
}
node *change(node *root,int n)
{
  node *cur;
  add data;
  cur=search(root,n);
  if(cur!=NULL)
    {
      printf("Nhap du lieu moi:");
      inp(&data);
      cur->data=data;
    }
  else
    printf("Cant find data\n");
  return root;
}
void *update(node *root,FILE *f)
{
  node *tmp;
  add data;
  tmp=(node *)malloc(sizeof(node));
  for(tmp=root;tmp!=NULL;tmp=tmp->next)
    {
      data=tmp->data;
      fwrite(&data,sizeof(add),1,f);
    }
  free(tmp);
}
int check_data(char dt[])
{
  char buff[MAX];
  int i;
  strcpy(buff,dt);
  for(i=0;buff[i]!='\0';i++)
    if ('0'>buff[i]||buff[i]>'9') return 0;
  return 1;
}

node *re(node *root)
{
  node *old,*cur,*tmp;
  tmp=root->next;
  root->next=NULL;
  while(tmp!=NULL)
    {
      cur=(node *)malloc(sizeof(node));
      cur->data=tmp->data;
      cur->next=root;
      root=cur;
      old=tmp;
      tmp=tmp->next;
      free(old);
    }
  return root;
}
void find1(node *root,char buff[])
{
  node *cur=NULL;
  int dem=0;
  for(cur=root;cur!=NULL;cur=cur->next)
    if(strcmp(buff,cur->data.name)==0)
      printf("%d-Ten:%s\nEmail:%-40sDT:%s\n\n",++dem,cur->data.name,cur->data.email,cur->data.dt);
  if(dem==0) printf("Cant file data\n");
}
void find2(node *root,char buff[])
{
  node *cur=NULL;
  int dem=0;
  for(cur=root;cur!=NULL;cur=cur->next)
    if(strcmp(buff,cur->data.dt)==0)
      printf("\n%d-Ten:%s\nEmail:%-40sDT:%s\n\n",++dem,cur->data.name,cur->data.email,cur->data.dt);
  if(dem=0) printf("Cant file data\n");
}
