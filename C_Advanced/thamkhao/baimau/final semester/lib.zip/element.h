#include<stdio.h>
#define MAX 80
typedef struct elementtype
{
  int i;
}elementtype;

