#include<stdio.h>
#define MAX 80
typedef struct elementtype
{
  char user[MAX];
  char pass[MAX];
}elementtype;

