#include<stdio.h>
#include<string.h>
#include"lib_Tree.h"
int cmp(elementtype data1,elementtype data2)
{
  return strcmp(data1.user,data2.user);
}
void print(elementtype data)
{
  printf("%s\n",data.user);
}
int check(elementtype data)
{
  int i;
  char ch;
  for(i=0;data.user[i]!='\0';i++)
    if(data.user[i]==' ') {printf("Username mustn't contain space\n");return 1;}
  if(strlen(data.pass)<6) {printf("Length of pass is at least 6 characters\n"); return 1;}
  for(i=0;data.pass[i]!='\0';i++)
    if((ch=data.pass[i])!='_'&&ch!='$'&&ch<'a'&&ch>'z'&&ch<'A'&&ch>'Z'&&ch<'0'&&ch>'9')
      {printf("Password contain only _,$, alphabet characters or figtures\n");return 1;}
}
node *get(FILE *f)
{
  node *tree=NULL;
  elementtype data;
  rewind(f);
  while(!feof(f))
    {
      fscanf(f,"%s %s",data.user,data.pass);
      if(!feof(f))
        tree=insert(tree,data);
    }
  return tree;
}
void update(FILE *f,node *tree)
{
  if(tree!=NULL)
    {
      update(f,tree->left);
      fprintf(f,"%s %s\n",tree->data.user,tree->data.pass);
      update(f,tree->right);
    }
}
void reset(elementtype *data)
{
  strcpy((*data).user,"");
  strcpy((*data).pass,"");
}
int main()
{
  FILE *f;
  char passfile[]="pass.txt";
  node *user=NULL,*tmp;
  elementtype data;
  int i,dem,k;
  if((f=fopen(passfile,"r+"))==NULL)
    {printf("Cant open file\n");exit(1);}
  else
    {
      user=get(f);
      do
        {
          dem=0;
          do
            {
              if(dem==3) exit(1);
              reset(&data);
              printf("Username:");scanf("%[^\n]",data.user);
              while(getchar()!='\n');
              printf("Password:");scanf("%[^\n]",data.pass);
              while(getchar()!='\n');
              if(check(data)||((tmp=search(user,data))!=NULL&&strcmp(tmp->data.pass,data.pass)!=0)||tmp==NULL)
                {dem++;printf("Ban con %d lan dang nhap\n",3-dem);}
              else break;
              printf("Press 0 to shutdown\nPress 1 to countinue\n");
              scanf("%d",&k);
              if(k==0) exit(1);
            }while(1);              ;
          if(strcmp(tmp->data.user,"admin")!=0)
            {
              printf("Welcome %s\n",data.user);
              printf("1- Do something\n");
              printf("2- Change pass\n");
              printf("3- Log off\n");
              printf("0- Shutdown\n");
              k=0;
              do{
                switch(k)
                  {
                  case 1:break;
                  case 2:
                    do
                      {printf("Press new pass:");scanf("%[^\n]",data.pass);
                        while(getchar()!='\n');
                      }while(check(data));
                    strcpy(tmp->data.pass,data.pass);
                    break;
                  }
                scanf("%d",&k);
                while(getchar()!='\n');
              }while(k<3&&k>0);
            }
          else
            {
              k=0;
              printf("Welcome admin!\n");
              printf("1- Add a new user\n");
              printf("2- Change user's password\n");
              printf("3- Show list of user\n");
              printf("4- Log off\n");
              printf("0- Shutdow\n");
              do{
                switch(k)
                  {
                  case 1:
                    reset(&data);
                    do
                      {
                        printf("Enter new username:");scanf("%[^\n]",data.user);
                        while(getchar()!='\n');
                        strcpy(data.pass,"000000");
                      } while(check(data));
                    if(search(user,data)!=NULL) printf("This name is existed\n");
                    else
                      {
                        do
                          {printf("Enter password:");scanf("%[^\n]",data.pass);
                            while(getchar()!='\n');
                          }while(check(data));
                        user=insert(user,data);
                      }
                    break;
                  case 2:
                    reset(&data);
                    do
                      {
                        printf("Enter user's username you want to change pass:");
                        scanf("%s[^\n]",data.user);
                        while(getchar()!='\n');
                        strcpy(data.pass,"000000");
                      }while(check(data));
                    if((tmp=search(user,data))==NULL)
                      printf("Cant file user whose name %s\n",data.user);
                    else
                      {
                        do
                          {
                            printf("Enter new password:");
                            scanf("%[^\n]",data.pass);
                            while(getchar()!='\n');
                          }while(check(data));
                      }
                    break;
                  case 3:
                    show(user,0);
                    break;
                  }
                scanf("%d",&k);
                while(getchar()!='\n');
              }while(k>0&&k<4);
            }
        }while(k!=0);
      rewind(f);
      update(f,user);
      fclose(f);
    }
  return 0;
}
