#include<stdio.h>
#include<stdlib.h>
#define MAX 80
typedef struct add
{char name[MAX];long memori;}add;
typedef struct node
{add data;struct node *next;struct node *prev;}node;
typedef struct queue
{node *front,*rear;}queue;
void make(queue *q)
{
  node *tmp;
  tmp=(node*)malloc(sizeof(node));
  tmp->next=NULL;tmp->prev=NULL;
  q->front=q->rear=tmp;
}
void *enq(queue *q,add data)
{
  node *new;
  new=(node*)malloc(sizeof(node));
  new->prev=q->rear;
  new->next=NULL;
  q->rear->data=data;
  q->rear->next=new;
  q->rear=new;
}
add deq(queue *q)
{
  node *tmp;
  add data;
  if(q->front!=q->rear)
    {tmp=q->front;
      q->front=q->front->next;q->front->prev=NULL;
      data=tmp->data;
      free(tmp);
      return (data);
    }
  else
    printf("Queue is empty\n");
}
node *insert(node *root,add data)
{
  node *new;
  new=(node*)malloc(sizeof(node));
  new->data=data;
  new->next=root;
  new->prev=NULL;
  if(root!=NULL) root->prev=new;
  root=new;
  return root;
}
node *kill(node *root,char str[],long *mem)
{
  node *tmp;
  *mem=0;
  for(tmp=root;tmp!=NULL;tmp=tmp->next)
    if(strcmp(tmp->data.name,str)==0)
      {
        *mem=tmp->data.memori;
        if(tmp->next!=NULL&&tmp->prev!=NULL)
          { tmp->next->prev=tmp->prev;
            tmp->prev->next=tmp->next;
            free(tmp);}
        else
          if(tmp==root)
            if(root->next==NULL) root=NULL;
            else{root=root->next;root->prev=NULL; free(tmp);}
          else
            {tmp->prev->next=NULL;free(tmp);}
        printf("%ld MB dc giai phong\n",*mem);
        break;
      }
  if(tmp==NULL) printf("Cant find data\n");
  return root;
}
void show(queue q)
{
  node *tmp;
  for(tmp=q.front;tmp!=q.rear;tmp=tmp->next)
    printf("%-40s%-10ld\n",tmp->data.name,tmp->data.memori);
}
void show_r(node *root)
{
  node *tmp;
  for(tmp=root;tmp!=NULL;tmp=tmp->next)
    printf("%-40s%-10ld\n",tmp->data.name,tmp->data.memori);
}
void free_n(node *root)
{
  node *tmp;
  tmp=root;
  while(tmp!=NULL)
    {root=root->next;free(tmp);tmp=root;}
}
