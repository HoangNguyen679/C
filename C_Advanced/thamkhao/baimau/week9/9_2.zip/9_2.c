#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"lib_q.h"
int main()
{
  queue q;
  node *root=NULL;
  int n,i;
  add data;
  long mem,sum=0,max;
  char str[MAX];
  make(&q);
  printf("Dung luong RAM:");scanf("%ld",&max);
  printf("GIOI HAN BO NHO CUA MAY LA %ld MB\n",max);
  printf("Menu:\n");
  printf("1-Dua vao danh sach chuong trinh\n");
  printf("2-Kill\n");
  printf("3-show\n");
  printf("4-Exit\n");
  printf("-----Nhap 0 de hien thi menu-----\n");
  do{
    printf("Chon:");
    scanf("%d",&n);
    switch(n)
      {
      case 0:
         printf("GIOI HAN BO NHO CUA MAY LA %ld MB\n",max);
         printf("Menu:\n");
         printf("1-Dua vao danh sach chuong trinh\n");
         printf("2-Kill\n");
         printf("3-show\n");
         printf("4-Exit\n");
         printf("-----Nhap 0 de hien thi menu-----\n");
         break;
      case 1:
        printf("Nhap ten chuong trinh(ID):");scanf("%s",str);
        printf("Bo nho chuong trinh:");scanf("%ld",&mem);
        if(mem>max)
          {printf("Chuong trinh co bo nho vuot qua gioi han\n");break;}
        strcpy(data.name,str);
        data.memori=mem;
        if((sum+mem)<=max&&(q.front==q.rear))
          {root=insert(root,data);sum=sum+mem;}
        else
          {
            printf("Chuong trinh se dc dua vao hang doi\n");
            enq(&q,data);
          }
        printf("Memori=%ld/%ld\n",sum,max);
        break;
      case 2:
        printf("Nhap ID chuong trinh muon kill:");scanf("%s",str);
        root=kill(root,str,&mem);
        sum=sum-mem;
        if(q.front!=q.rear)
          while(sum+q.front->data.memori<=max&&q.front!=q.rear)
            {data=deq(&q);root=insert(root,data);sum=sum+data.memori;}
        printf("Memori=%ld/%ld\n",sum,max);
        break;
      case 3:
        printf("Chuong trinh dang chay:-----\n");
        show_r(root);
        printf("Chuong trinh trong hang doi:----\n");
        show(q);
        break;
      case 4:
        free_n(root);free_n((&q)->front);
        break;
      }
  }while(n!=4);
  return 0;
}



