#include<stdio.h>
void menu(char str[])
{
  printf("Menu:\n");
  printf("1-Import data from file %s\n",str);
  printf("2-Insert data to list\n");
  printf("3-Delete data from list\n");
  printf("4-Search\n");
  printf("5-Update data\n");
  printf("6-Reserve list\n");
  printf("7-Devide list\n");
  printf("8-Show list\n");
  printf("9-Save to file %s\n",str);
  printf("10-Show file and export\n");
  printf("11-Exit\n");
  printf("+++*Chon 0 de tro lai menu chinh*+++\n");
}
void mini1()
{
  printf("1-Insert a new phone\n");
  printf("2-Insert at position\n");
  printf("0-Back to main menu\n");
}
void mini2()
{
  printf("1-Delete at first\n");
  printf("2-Delete at position\n");
  printf("3-Delete at current\n");
  printf("4-Delete a series (base on the first letter)\n");
  printf("0-Back to main menu\n");
}
void mini3()
{
  printf("1-Search a model\n");
  printf("2-Search a series (base on the first letter)\n");
  printf("0-Back to main menu\n");
}
void mini4()
{
  printf("1-Devide from first\n");
  printf("2-Devide from a position user enter\n");
  printf("0-Back to main menu\n");
}
void mini5()
{
  printf("1-Show file\n");
  printf("2-Save as ...\n");
  printf("0-Back to main menu\n");
}
