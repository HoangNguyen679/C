#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 81
typedef struct add
{char name[MAX],pixel[40];float memorti,gia;}add;
typedef struct node
{add data;struct node *next;struct node *pre;}node;
int CUR=0,TAIL=0;
void conv_dat(FILE *f1,FILE *f2)
{
  add data;
  rewind(f1);
  while(!feof(f1))
    {
      fscanf(f1,"%s%f%s%f",data.name,&(data.memorti),data.pixel,&(data.gia));
      if(!feof(f1))
        fwrite(&data,sizeof(add),1,f2);
    }
}
void inp(add *data)
{
  add tmp;
  char buff[MAX];
  while(getchar()!='\n');
  printf("Model:");scanf("%s",tmp.name);
  do{printf("Do phan giai:");scanf("%s",buff);}while(!check_data(buff));
  strcpy(tmp.pixel,buff);
  do{printf("Dung luong bo nho:");scanf("%f",&(tmp.memorti));}while(tmp.memorti<=0);
  do{printf("Gia(trieu):");scanf("%f",&(tmp.gia));}while(tmp.gia<=0);
  *data=tmp;
}
node *search_p(node *root,int n)
{
  node *tmp;
  int i=0;
  for(tmp=root;tmp!=NULL;tmp=tmp->next) {i++;if(i==n) break;}
  return tmp;
}
node *insert(node *root,add data,int n)
{
  node *new,*cur;
  if(n<0) return (root);
  new=(node *)malloc(sizeof(node));
  new->data=data;
  if(n==0)
    {new->next=root;new->pre=NULL;root=new;cur=root;CUR=1;}
  else
    {
      if(n>=TAIL) {cur=search_p(root,TAIL);CUR=TAIL+1;}
      else {cur=search_p(root,n);CUR=n+1;}
      new->next=cur->next;new->pre=cur;cur->next=new;cur=cur->next;
    }
  TAIL++;
  return(root);
}
node *insert_s(node *root,add data)
{
  node *new,*cur;
  new=(node*)malloc(sizeof(node));
  new->data=data;
  if(root==NULL)
    {new->next=NULL;new->pre=NULL;root=new;}
  else
    {for(cur=root;cur->next!=NULL;cur=cur->next)
        if(cur->data.gia>data.gia) break;
      if(cur==root)
        {new->next=root;new->pre=NULL;root=new;}
      else
        if(cur->next==NULL)
          if(cur->data.gia>data.gia)
            {new->next=cur;new->pre=cur->pre;cur->pre->next=new;cur->pre=new;}
          else{new->pre=cur;new->next=NULL;cur->next=new;}
        else
          {new->next=cur;new->pre=cur->pre;cur->pre->next=new;cur->pre=new;}
    }
  return root;
}
node *creat(node *root,FILE *f)
{
  node *new,*cur;
  add *data;
  int dem=0;
  rewind(f);
  root=NULL;
  TAIL=CUR=0;
  data=(add *)malloc(sizeof(add));
  while(!feof(f))
    {
      fread(data,sizeof(add),1,f);
      if(!feof(f))
        root=insert(root,*data,TAIL);
    }
  return(root);
}
node *delete(node *root,int n)
{
  node *cur;
  if(n<1||n>TAIL) return(root);
  if(1<n&&n<TAIL)
    {cur=search_p(root,n);
      cur->pre->next=cur->next;cur->pre->next=cur->pre;
      CUR=n-1;free(cur);}
  else
    if(TAIL==1) root=NULL;
        else
          if(n==1)
            {
              cur=root;
              root->next->pre=NULL;root=root->next;
              CUR=1;free(cur);
            }
          else
            {cur=search_p(root,TAIL);cur->pre->next=NULL;CUR=TAIL-1;free(cur);}
  TAIL--;
  return (root);
}
void show(node *root)
{
  node *cur=NULL;
  int dem=0;
  printf("%-3s%-40s%-15s%-10s%-10s\n","TT","Model","Phan giai","Bo nho","Gia(trieu)");
  for(cur=root;cur!=NULL;cur=cur->next)
    printf("%-3d%-40s%-15s%-10g%-10g\n",++dem,cur->data.name,cur->data.pixel,cur->data.memorti,cur->data.gia);
}
void free_n(node *root)
{
  node *to_free;
  to_free=(node*)malloc(sizeof(node));
  to_free=root;
  while(to_free!=NULL)
    {root=root->next;free(to_free);to_free=root;}
}
node *change(node *root,int n)
{
  node *cur;
  add data;
  cur=search_p(root,n);
  if(cur!=NULL)
    {
      printf("Nhap du lieu moi:");
      inp(&data);
      cur->data=data;
    }
  else
    printf("Cant find data\n");
  return root;
}
void update(node *root,FILE *f)
{
  node *tmp;
  add data;
  rewind(f);
  for(tmp=root;tmp!=NULL;tmp=tmp->next)
    {
      data=tmp->data;
      fwrite(&data,sizeof(add),1,f);
    }
}
void show_f(FILE *f)
{
  add *data;
  int dem=0;
  data=(add*)malloc(sizeof(add));
  rewind(f);
  printf("%-3s%-40s%-15s%-10s%-10s\n","TT","Model","Phan giai","Bo nho","Gia");
  while(!feof(f))
    {fread(data,sizeof(add),1,f);
      if(!feof(f))
        printf("%-3d%-40s%-15s%-10g%-10g\n",++dem,data->name,data->pixel,data->memorti,data->gia);
    }
  free(data);
}
int check_data(char dt[])
{
  char buff[MAX];
  int i,dem=0;
  strcpy(buff,dt);
  for(i=0;buff[i]!='\0';i++)
    if(buff[i]<'0'||buff[i]>'9')
      if(buff[i]!='x') return 0;
      else dem++;
  if(dem!=1) return 0;
  return 1;
}
node *re(node *root)
{
  node *cur=NULL,*tmp=NULL;
  tmp=root->next;
  root->next=NULL;
  while(tmp!=NULL)
    {cur=tmp;tmp=tmp->next;cur->next=root;cur->pre=NULL;root=cur;}
  CUR=1;
  return root;
}
void find1(node *root,char buff[])
{
  node *cur=NULL;
  int dem=0;
  printf("%-3s%-40s%-15s%-10s%-10s\n","TT","Model","Phan giai","Bo nho","Gia");
  for(cur=root;cur!=NULL;cur=cur->next)
    if(strcmp(buff,cur->data.name)==0)
      printf("%-3d%-40s%-15s%-10g%-10g\n",++dem,cur->data.name,cur->data.pixel,cur->data.memorti,cur->data.gia);
  printf("Tim thay %d ket qua\n",dem);
}
void find2(node *root,char ch)
{
  node *cur=NULL,*tmp=NULL;
  int dem=0;
  for(cur=root;cur!=NULL;cur=cur->next)
    if(ch==cur->data.name[0])
      {tmp=insert_s(tmp,cur->data);dem++;}
  show(tmp);
  printf("Tim thay %d ket qua\n",dem);
  free_n(tmp);
}
node *devide(node *root)
{
  int n,n1,c1;
  char ch;
  node *cur=NULL,*cur2=NULL;
  printf("Select:");
  scanf("%d",&c1);
  switch(c1)
    {
    case 0: break;
    case 1:
      printf("Point to position u want to devide from\n");
      scanf("%d",&n);
      if(n<=0) break;
      if(n>TAIL) printf("No enough data to devide\n");
      else
        {cur=search_p(root,n);cur=cur->next;cur->pre->next=NULL;cur->pre=NULL;}
      break;
    case 2:
      printf("Where to start?");scanf("%d",&n);
      if(n<=0) break;
      if(n>TAIL) printf("No enough data to devide\n");
      else
        {printf("How many data in new list?");scanf("%d",&n1);
          if(TAIL<n1+n) printf("No enough data to devide\n");
          else
            {cur=search_p(root,n)->next;
              cur2=search_p(cur,n1)->next;
              if(cur2==NULL)
                {cur->pre->next=NULL;cur->pre=NULL;}
              else
                {cur2->pre->next=NULL;cur2->pre=cur->pre;cur2->pre->next=cur2;cur->pre=NULL;}
            }
        }
      break;
    }
  if(n>0&&n<TAIL)
    if(c1==1||c1==2)
      {printf("This is the first list:");show(root);
        printf("This is the second list:");show(cur);
        if(cur2==NULL)
          {cur->pre=search_p(root,n);cur->pre->next=cur;}
        else
          if(n1+n<=TAIL)
            {cur2->pre->next=cur;cur->pre=cur2->pre;cur2->pre=search_p(cur,n1);cur2->pre->next=cur2;}
      }
  return root;
}
void write(FILE *f,node *root)
{
  node *tmp;
  for(tmp=root;tmp!=NULL;tmp=tmp->next)
    fprintf(f,"%-40s%-15s%-9f%-9f\n",tmp->data.name,tmp->data.pixel,tmp->data.memorti,tmp->data.gia);
}
