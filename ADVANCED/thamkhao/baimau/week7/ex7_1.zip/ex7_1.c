#include<stdio.h>
#include<stdlib.h>
#include"lib.h"
#include"layout.h"
#define MAX 81
int main()
{
  char dat[]="NokiaDB.dat";
  FILE *f,*fr;
  node *root=NULL,*cur=NULL;
  add data;
  char name[MAX],ch;
  int chon,n,c1,c2,tmp;
  menu(dat);
  do{
    printf("Select:");
    scanf("%d",&chon);
    switch(chon)
      {
      case 0:menu(dat);break;
      case 1:
        if((f=fopen(dat,"r+b"))==NULL)
          {printf("Cant open file %s\n",dat);break;}
        else
          {root=creat(root,f);fclose(f);}
        break;
      case 2:
        mini1();
        printf("Select:");
        scanf("%d",&c1);
        switch(c1)
          {
          case 0:menu(dat);break;
          case 1:
            printf("Enter data:");
            inp(&data);
            root=insert(root,data,TAIL);
            break;
          case 2:
            printf("Enter data:");
            inp(&data);
            printf("Select position to insert:");
            scanf("%d",&n);
            insert(root,data,n);
            break;
          }
        break;
      case 3:
        if(TAIL==0) {printf("Nothing to delete\n");break;}
        mini2();
        printf("Select:");
        scanf("%d",&c1);
        switch(c1)
          {
          case 0:menu(dat);break;
          case 1:root=delete(root,1);break;
          case 3:tmp=CUR;root=delete(root,tmp);break;
          case 2:
            printf("Tell me position of data u want to remove:");
            scanf("%d",&n);
            if(n>TAIL||n<0) printf("Somethings are wrong!!!\n");
            else root=delete(root,n);
          case 4:
            printf("Tell me what kind of series u want to del(enter the first letter):");
            while(getchar()!='\n');
            scanf("%c",&ch);
            n=1;cur=root;
            while(cur!=NULL)
              if(ch==cur->data.name[0]) {cur=cur->next;root=delete(root,n);}
              else{cur=cur->next;n++;}
            break;
          }
        break;
      case 4:
        if(TAIL==0) {printf("There is no data in list\n");break;}
        mini3();
        printf("Select:");scanf("%d",&c1);
        switch(c1)
          {
          case 0:menu(dat);break;
          case 1:
            printf("Model's name:");
            while(getchar()!='\n');
            scanf("%s",name);
            find1(root,name);
            break;
          case 2:
              printf("Tell me what kind of series u want to search(enter the first letter):");
            while(getchar()!='\n');
            scanf("%c",&ch);
            find2(root,ch);
            break;
          }
        break;
      case 5:
        if(TAIL==0) {printf("There is no data to fix\n");break;}
        printf("Tell me position of data u want to fix:");
        scanf("%d",&n);
        if(n<1||n>TAIL) printf("Somethings are wrong\n");
        else root=change(root,n);
        break;
      case 6:
        if(TAIL==0) {printf("There is no data to do\n");break;}
        root=re(root);printf("Done!\n");break;
      case 7:
        if(TAIL==0) {printf("There is no data to do\n");break;}
        mini4();
        root=devide(root);
        menu(dat);
        break;
      case 8:
        show(root);
        break;
      case 9:
        if((f=fopen(dat,"w+b"))==NULL)
          {printf("Cant open file %s\n",dat);break;}
        else
          {update(root,f);fclose(f);}
        break;
      case 10:
        mini5();
        printf("Select:");
        scanf("%d",&c1);
        switch(c1)
          {
          case 0:menu(dat);break;
          case 1:
            if((f=fopen(dat,"r+b"))==NULL)
              {printf("Cant open file %s\n",dat);break;}
            else
              {show_f(f);fclose(f);}
            break;
          case 2:
            printf("File name:");
            while(getchar()!='\n');
            scanf("%s",name);
            if((fr=fopen(name,"w"))==NULL)
              {printf("Cant open file %s\n",name);break;}
            else
              {write(fr,root);fclose(fr);}
            break;
          }
        break;
      case 11:free_n(root);break;
      }
  }while(chon!=11);
  return 0;
}
