//Cau truc 4 file article,noun,verb,preposition:moi hang luu 1 tu
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
enum {SUCCESS,FAIL,MAX=81};
typedef char str[MAX];
void make_arr(FILE *f,str arr[],int *so)
{
  char buff[MAX];
  int d=0;
  while(fgets(buff,MAX,f)!=NULL)
    {strncpy(arr[d],buff,strlen(buff)-1);d++;}
  *so=d;
}
void pick(FILE *f1,FILE *f2,FILE *f3, FILE *f4)
{
  str art[20];
  str noun[20];
  str verb[20];
  str prep[20];
  long save[20];
  int len[4],r[6],i,j;
  srand(time(NULL));
  make_arr(f1,art,&len[0]);make_arr(f2,noun,&len[1]);
  make_arr(f3,verb,&len[2]);make_arr(f4,prep,&len[3]);
  for(i=0;i<10;i++)
    {
      do
        {
          for(j=0;j<6;j++)
            r[j]=rand()%len[j%4];
        }while(check(r,save,i));
      save[i]=r[0]*100000+r[1]*10000+r[2]*1000+r[3]*100+r[4]*10+r[5];
      in(r,art,noun,verb,prep);
    }
}
int in(int r[],str art[],str noun[],str verb[],str  prep[])
{
  int i=0;
  char s[MAX];
  strcpy(s,art[r[0]]);up(s);
  printf("%s %s %s %s %s %s.\n",s,noun[r[1]],verb[r[2]],prep[r[3]],art[r[4]],noun[r[5]]);
  return i;
}
int up(char s[])
{
  s[0]=s[0]-32;
  return 0;
}
int check(int r[],long save[],int i)
{
  int j;
  long sum;
  if (i==0) return 0;
  do{i--;
    sum=0;
    for(j=0;j<6;j++) sum=r[j]+sum*10;
    if(sum==save[i]) return 1;
  }while(i!=0);
  return 0;
}
int main()
{
  FILE *f1,*f2,*f3,*f4;
  char article[]="article",noun[]="noun",verb[]="verb",prep[]="prep";
  int re=SUCCESS;
  if((f1=fopen(article,"r"))==NULL)
    {printf("Cant open file %s\n",article);re=FAIL;}
  else
    {if((f2=fopen(noun,"r"))==NULL)
        {printf("Cant open file %s\n",noun);re=FAIL;}
      else
        {if((f3=fopen(verb,"r"))==NULL)
            {printf("Cant open file %s\n",verb);re=FAIL;}
          else
            {if((f4=fopen(prep,"r"))==NULL)
                {printf("Cant open file %s\n",prep);re=FAIL;}
              else
                {pick(f1,f2,f3,f4);
                  fclose(f4);}
              fclose(f3);}
          fclose(f2);}
      fclose(f1);}
  return 0;
}
