#include<stdio.h>
#define MAX 80
typedef struct elementtype
{
  char tu[MAX];
  char nghia[MAX];
}elementtype;

