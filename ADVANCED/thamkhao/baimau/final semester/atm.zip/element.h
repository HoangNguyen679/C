#include<stdio.h>
#define MAX 80
typedef struct base
{
  char name[MAX];
  char id[MAX];
}base;
typedef struct elementtype
{
  char user[MAX];
  char pass[MAX];
  base info;
  int money;
}elementtype;
