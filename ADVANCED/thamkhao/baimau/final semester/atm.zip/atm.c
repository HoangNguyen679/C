#include<stdio.h>
#include<string.h>
#include"lib_Tree.h"
#define MIN 50
int cmp(elementtype data1,elementtype data2)
{
  return strcmp(data1.user,data2.user);
}
void print(elementtype data)
{
  printf("===============================\n");
  printf("ID:%15s\nChu TK:%-30s\nTK:%10d\n",data.user,data.info.name,data.money);
  printf("===============================\n");
}
int check(elementtype data)
{
  int i;
  char ch;
  for(i=0;data.user[i]!='\0';i++)
    if(data.user[i]==' ') {printf("Username mustn't contain space\n");return 1;}
  if(strlen(data.pass)!=6) {printf("Length of pass must be 6\n"); return 1;}
  for(i=0;data.pass[i]!='\0';i++)
    if((ch=data.pass[i])!='_'&&ch!='$'&&ch<'a'&&ch>'z'&&ch<'A'&&ch>'Z'&&ch<'0'&&ch>'9')
      {printf("Password contain only _,$, alphabet characters or figtures\n");return 1;}
}
void hoadon(elementtype data,int n)
{
  printf("ID:%-15s\nChu TK:%-30s\n",data.user,data.info.name);
  printf("Ngay:xx/xx/xxx\n");
  printf("Before:%15d\n",data.money);
  printf("After: %15d\n",data.money-n);
  printf("==========================\nIDE Bank - Welcome\n");
}
node *get(FILE *f)
{
  node *tree=NULL;
  elementtype data;
  rewind(f);
  while(!feof(f))
    {
      fscanf(f,"%s %6s %d %s %[^\n]",data.user,data.pass,&(data.money),data.info.id,data.info.name);
      if(!feof(f))
        tree=insert(tree,data);
    }
  return tree;
}
void update(FILE *f,node *tree)
{
  if(tree!=NULL)
    {
      update(f,tree->left);
      fprintf(f,"%s %6s %d %s %s\n",tree->data.user,tree->data.pass,tree->data.money,tree->data.info.id,tree->data.info.name);
      update(f,tree->right);
    }
}
void reset(elementtype *data)
{
  strcpy((*data).user,"");
  strcpy((*data).pass,"");
}
int main()
{
  FILE *f;
  char passfile[]="pass.txt";
  node *user=NULL,*tmp,*tmp2;
  elementtype data,dtmp;
  int i,dem,k,n;
  char ch;
  if((f=fopen(passfile,"r+"))==NULL)
    {printf("Cant open file\n");exit(1);}
  else
    {
      user=get(f);
      do
        {
          dem=0;
          do
            {
              if(dem==3) exit(1);
              reset(&data);
              printf("ID card:");scanf("%[^\n]",data.user);
              while(getchar()!='\n');
              printf("Password:");scanf("%[^\n]",data.pass);
              while(getchar()!='\n');
              if(check(data)||((tmp=search(user,data))!=NULL&&strcmp(tmp->data.pass,data.pass)!=0)||tmp==NULL)
                {dem++;printf("Ban con %d lan dang nhap\n",3-dem);}
              else break;
              printf("Press any key to continue!\n");
              if(getchar()=='0') k=0; else k=1;
              if(k==0) exit(1);
              while(getchar()!='\n');
            }while(1);
          data=tmp->data;
          do
            {
              printf("IDE Bank - Welcome %s\n",data.info.name);
              printf("1- Check account\n");
              printf("2- Take money\n");
              printf("3- Tranfer money\n");
              printf("4- Change pass\n");
              printf("0- Exit\n");
              scanf("%d",&k);
              while(getchar()!='\n');
              switch(k)
                {
                case 1:
                  print(data);
                  break;
                case 2:
                  printf("How much you want to take?\n");
                  printf("1> 100.000 d\n2> 500.000\n3> 1.000.000\n4> 3.000.000\n");
                  printf("5> Enter an another number\n");
                  scanf("%d",&i);
                  while(getchar()!='\n');
                  switch(i)
                    {
                    case 1: n=100; break;
                    case 2: n=500; break;
                    case 3: n=1000; break;
                    case 4: n=3000; break;
                    case 5:
                      printf("Enter a number:");
                      scanf("%d",&n);
                      while(getchar()!='\n');
                      break;
                    }
                  if(0<i&&i<6)
                    {
                      if(n>3000) printf("You take maximum 3.000.000 each time\nOK!\n");
                      else
                        if(n<0) printf("Wrong number\n");
                        else
                          if(data.money<n+MIN)
                            printf("Sorry! Your account isn't enough\n");
                          else
                            {
                              printf("OK! I got it\nPlease wait a minute\nOK\n");
                              data.money-=n;
                              printf("Do you want to print receipt?\n");
                              scanf("%c",&ch);
                              if(ch=='y'||ch=='Y')
                                hoadon(data,n);
                            }
                    }
                  else printf("Wrong choice\n");
                  break;
                case 3:
                  do{
                    printf("Enter account you want to tranfer money:");
                    scanf("%s",dtmp.user);
                    while(getchar()!='\n');
                  }while(strcmp(dtmp.user,data.user)==0);
                  if((tmp2=search(user,dtmp))==NULL)
                    {printf("No account has that ID! Maybe have some wrong here\n");break;}
                  printf("How much you want to tranfer?\n");
                  scanf("%d",&n);
                  while(getchar()!='\n');
                  if(n+MIN<data.money)
                    {data.money-=n;tmp2->data.money+=n;
                      printf("OK! Done !\n");}
                  else printf("This account isn't enough\n");
                  break;
                case 4:
                  do
                    {
                      printf("Press new pass:");scanf("%[^\n]",data.pass);
                      while(getchar()!='\n');
                    }while(check(data));
                  strcpy(tmp->data.pass,data.pass);
                  break;
                }
              tmp->data=data;
            }while(k<5&&k>0);
        }while(1);
      rewind(f);
      update(f,user);
      fclose(f);
    }
  return 0;
}
