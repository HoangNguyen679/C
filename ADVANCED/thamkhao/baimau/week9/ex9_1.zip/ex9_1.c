#include<stdio.h>
#include<stdlib.h>
#include"lib_q2.h"
#define max 10
typedef struct quay
{add time;int stt,doi;}quay;
int a,XL,q;
add work1,work2;
queue hang[max];
quay pv[max];
int cmp(add time1,add time2)
{
  return (time1.gio-time2.gio)*60+(time1.phut-time2.phut);
}
int check(add m)
{
  if(m.gio>23||m.gio<0||m.phut>60||m.phut<0) {printf("Nhap thoi gian khong hop le\n");return 1;}
  if(cmp(m,work1)<0||cmp(m,work2)>0) {printf("Ngoai gio lam viec\n");return 1;}
  return 0;
}
add plus(add time,int i)
{
  time.gio+=(time.phut+i)/60;
  time.phut=(time.phut+i)%60;
  return time;
}
void vao(add m,int kh,int dem,int *dem_kh,long *dem_tg)
{
  int i,j,doi=0;
  for(j=dem;j<dem+kh;j++)
    {
      i=j%q;
      if(pv[i].stt==-1) continue; //Qua gio lam viec
      //
      //Xu ly truoc khi dua them phan tu vao hang doi
      if(pv[i].stt==0)            //Quay rong
        {if(!isempty(hang[i])) {pv[i].time=deq(&(hang[i])); pv[i].stt=1; (*dem_kh)++;}}
      else                        //Quay dang co nguoi
        {
          while(!isempty(hang[i])&&(cmp(m,hang[i].front->data)-cmp(hang[i].front->data,pv[i].time))>=0)
            {
              doi=XL-cmp(hang[i].front->data,pv[i].time);
              pv[i].time=plus(deq(&(hang[i])),doi);
              pv[i].doi=pv[i].doi-doi;
            }
          // Xu ly khi hang doi rong
          if(isempty(hang[i]))
            if(cmp(m,pv[i].time)>=XL)
              {pv[i].time=m;pv[i].stt=0;pv[i].doi=0;}
        }
      //
      //Xep va xu ly dua phan tu moi vao hang doi
      if((pv[i].stt==0)&&(!check(plus(m,XL))))
        {
          pv[i].time=m;pv[i].stt=1;(*dem_kh)++;
          printf("Khach hang thu %d vao quay so %d\n",j-dem+1,i+1);
        }
      else
        {
          if(isempty(hang[i])) pv[i].doi=XL-cmp(m,pv[i].time);
          else pv[i].doi+=XL;
          if(!check(plus(m,pv[i].doi+XL)))
            {
              enq(&(hang[i]),m);(*dem_tg)+=pv[i].doi;(*dem_kh)++;
              printf("Khach hang thu %d vao hang %d doi:%d phut\n",j-dem+1,i+1,pv[i].doi);
            }
          else
            pv[i].stt=-1;
        }
    }
}
int main(int argc,char* argv[])
{
  FILE *f;
  char buff[MAX];
  int dem_kh=0,kh,dem=0,i;
  long dem_tg=0;
  add m;
  if(argc!=2)
    {printf("sai cu phap:%s <ten file du lieu>\n",argv[0]);exit(1);}
  if((f=fopen(argv[1],"r"))==NULL)
    {printf("Cant open file\n");exit(1);}
  else
    {
      printf("Ngan hang ABC\nThong tin:\n");
      printf("Thoi gian bat dau lam viec:");scanf("%d:%d",&(work1.gio),&(work1.phut));
      printf("Thoi gian ket thuc lam viec:");scanf("%d:%d",&(work2.gio),&(work2.phut));
      printf("Thoi gian xu ly 1 giao dich:");scanf("%d",&XL);
      printf("So quay phuc vu trong ngan hang:");scanf("%d",&q);
      printf("\n-----------------------------------------------------\n");
      //khoi tao
      for(i=0;i<q;i++)
        {make(&(hang[i]));pv[i].stt=pv[i].doi=0;}
      fscanf(f,"%[^\n]",buff);
      //Bat dau doc
      while(!feof(f))
        {fscanf(f,"%d:%d%d",&m.gio,&m.phut,&kh);
          if(!feof(f))
            {
              if(check(m)!=1)
                {
                  printf("%2d:%02d%40d khach hang\n",m.gio,m.phut,kh);
                  vao(m,kh,dem,&dem_kh,&dem_tg);
                  dem+=kh;
                }
            }
        }
      //Thong ke
      printf("\n-----------------------------------------------------\n");
      printf("Hom nay da phuc vu giao dich cho %d khach hang\n",dem_kh);
      printf("Tong thoi gian cho:%ld\n",dem_tg);
      printf("Thoi gian cho trung binh la:%.1f\n",dem_tg/(dem_kh*1.0));
      fclose(f);
    }
  return 1;
}
