#include<stdio.h>
#include<stdlib.h>
#include"lib.h"
int main()
{
  node *root1,*root2,*tmp;
  char data1[]="data1.dat",data2[]="data2.dat";
  int dem1,dem2,dem;
  int check;
  root1=creat(data1);
  root2=creat(data2);
  dem1=dem2=dem=0;
  for(tmp=root1;tmp!=NULL;tmp=tmp->next)
    if(find(tmp->data,root2,&check)==0) dem1++;
    else
      if(check==1) dem++;
  for(tmp=root2;tmp!=NULL;tmp=tmp->next)
    if(find(tmp->data,root1,&check)==0) dem2++;
  printf("Danh sach 1:\n");
  show(root1);
  printf("-------------------------------------\n");
  printf("Danh sach 2:\n");
  show(root2);
  printf("-------------------------------------\n");
  printf("Ket qua so sanh:\n");
  printf("So luong node co ten o DS1 ma k co o DS2:%d\n",dem1);
  printf("So luong node co ten o DS2 ma k co o DS1:%d\n",dem2);
  printf("So luong node co ten o DS1 va DS2 nhung kac nhau:%d\n",dem);
  return 0;
}
