#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 81
#define es 0.00001
typedef struct add
{char name[MAX],pixel[40];float memorti,gia;}add;
typedef struct node
{add data;struct node *next;}node;
void conv_dat(char *str1,char *str2)
{
  add data;
  FILE *f1,*f2;
  if((f1=fopen(str1,"r"))==NULL)
    printf("Cant open file %s\n",str1);
  else
    {if((f2=fopen(str2,"wb"))==NULL)
        printf("Cant open file %s\n",str2);
      else
        {
        while(!feof(f1))
          {
            fscanf(f1,"%s%f%s%f",data.name,&(data.memorti),data.pixel,&(data.gia));
            if(!feof(f1))
              {fwrite(&data,sizeof(add),1,f2);printf("%s\n",data.name);}
          }
        fclose(f2);
      }
      fclose(f1);
    }
}
int size(node *root,node *tail)
{
  node *tmp;
  int dem=0;
  for(tmp=root;tmp!=tail;tmp=tmp->next) dem++;
  return dem;
}
node *seek(node *root,int n)
{
  node *tmp;
  for(tmp=root;tmp!=NULL&&n!=0;tmp=tmp->next) n--;
  return tmp;
}
int cmp(add data1,add data2)
{
  if(strcmp(data1.pixel,data2.pixel)==0)
    if(data1.memorti==data2.memorti)
      if(data1.gia==data2.gia)
        return 1;
  return 0;
}
int find(add data,node *root,int *check)
{
  node *head,*tail,*mid;
  int len1,len2,n;
  (*check)=0;
  head=root;tail=NULL;
  do
    {len1=1;len2=size(head,tail);
      mid=seek(head,(len1+len2)/2-1);
      if(strcmp(data.name,mid->data.name)==0)
        {
          if(cmp(mid->data,data)) {(*check)=0;return 1;}
          else{(*check)=1; return 1;}
        }
      else
        {
          if(strcmp(data.name,mid->data.name)>0) head=mid->next;
          else
            tail=mid;
        }
    }while(head!=tail);
  return 0;
}
node *insertS(node *root,add data)
{
  node *new,*tmp,*prev;
  new=(node *)malloc(sizeof(node));
  new->data=data;
  new->next=NULL;
  if(root==NULL) return new;
  else
    {
      prev=NULL;
      for(tmp=root;tmp!=NULL;tmp=tmp->next)
        {if(strcmp(tmp->data.name,data.name)>0) break;
          prev=tmp;}
      if(prev==NULL){new->next=root;root=new;}
      else
        {new->next=prev->next;prev->next=new;}
      return root;
    }
}
node *creat(char *str)
{
  node *root=NULL;
  add *data;
  FILE *f;
  if((f=fopen(str,"rb"))==NULL)
    {printf("Cant open file %s\n",str);exit(1);}
  else
    {
      data=(add *)malloc(sizeof(add));
      while(!feof(f))
        {
          fread(data,sizeof(add),1,f);
          if(!feof(f))
            root=insertS(root,*data);
        }
      fclose(f);
      return(root);
    }
}
void show(node *root)
{
  int n=0;
  node *cur=NULL;
  printf("%-4s%-25s%-10s%-15s%-20s\n","TT","Ten SP","Bo nho(GB)","Phan giai","Gia(trieu dong)");
  for(cur=root;cur!=NULL;cur=cur->next)
    printf("%-4d%-25s%-10.1f%-15s%-15.6f\n",++n,cur->data.name,cur->data.memorti,cur->data.pixel,cur->data.gia);
  free(cur);
}
void free_n(node *root)
{
  node *to_free;
  to_free=(node*)malloc(sizeof(node));
  to_free=root;
  while(to_free!=NULL)
    {root=root->next;free(to_free);to_free=root;}
}
void show2(char str[])
{
  add *data;
  int n=0;
  FILE *f;
  data=(add*)malloc(sizeof(add));
  if((f=fopen(str,"rb"))==NULL)
    {printf("Cant open file %s\n",str);exit(1);}
  else
    {
      while(!feof(f))
        {
          fread(data,sizeof(add),1,f);
          if(!feof(f))
            printf("%-4d%-25s%-10.1f%-15s%-15.6f\n",++n,data->name,data->memorti,data->pixel,data->gia);
        }
    }
  fclose(f);
}
