#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAXL 20

typedef struct Student_t{
  int id;
  char name[MAXL];
  int grade;
} Student;

Student student[100];

int main(int argc, char *argv[]){
  if(argc != 5) {
    printf("Invalid argument!\n");
    return 1;
  }

  FILE *fin, *fout1, *fout2;
  if((fin = fopen(argv[1], "rb")) == NULL) {
    perror("ERROR");
    return 1;
  }
  if((fout1 = fopen(argv[3], "wb")) == NULL ||
     (fout2 = fopen(argv[4], "wb")) == NULL){
    perror("ERROR");
    return 1;
  }

  int i, numberOfStudent;
  numberOfStudent = fread(student, sizeof(Student), 100, fin);
  for(i = 0; i < numberOfStudent-1; i++)
    printf("%-2d %-20s %-2d\n", student[i].id, student[i].name,
	   student[i].grade);

  int toFile1 = atoi(argv[2]);
  //for(i = 0; i < freadReturn-1; i++)
  fwrite(student, sizeof(Student), toFile1, fout1);

  fwrite(student+toFile1, sizeof(Student), numberOfStudent-toFile1-1, fout2);


  fclose(fin);
  fclose(fout1);
  fclose(fout2);
  return 0;
}
