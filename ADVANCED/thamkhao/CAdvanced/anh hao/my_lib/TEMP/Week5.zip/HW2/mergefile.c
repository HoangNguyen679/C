#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAXL 20

typedef struct Student_t{
  int id;
  char name[MAXL];
  int grade;
} Student;

Student student[100];

int main(int argc, char *argv[]){
  if(argc != 4) {
    printf("Invalid argument!\n");
    return 1;
  }

  FILE *fin1, *fin2, *fout;
  if((fin1 = fopen(argv[1], "rb")) == NULL ||
     (fin2 = fopen(argv[2], "rb")) == NULL) {
    perror("ERROR");
    return 1;
  }

  if((fout = fopen(argv[3], "wb")) == NULL){
    perror("ERROR");
    return 1;
  }


  int num1 = fread(student, sizeof(Student), 100, fin1);
  fwrite(student, sizeof(Student), num1, fout);

  int num2 = fread(student, sizeof(Student), 100, fin2);
  fwrite(student, sizeof(Student), num2, fout);

  fclose(fin1);
  fclose(fin2);
  fclose(fout);

  return 0;
}
